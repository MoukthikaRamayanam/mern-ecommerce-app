/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['DM Sans', 'sans-serif'],
        display: ['Syne', 'sans-serif'],
      },
      colors: {
        brand: {
          50: '#fff7ed',
          500: '#f97316',
          600: '#ea6c0a',
          700: '#c2570b',
        },
      },
    },
  },
  plugins: [],
};
