import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';

export default function Navbar() {
  const { user, logout } = useAuth();
  const { totalItems } = useCart();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav className="bg-white border-b border-gray-100 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-16">
        {/* Logo */}
        <Link to="/" className="font-display text-xl font-bold text-gray-900">
          Shop<span className="text-orange-500">Flow</span>
        </Link>

        {/* Links */}
        <div className="flex items-center gap-4 text-sm font-medium">
          <Link to="/" className="text-gray-600 hover:text-orange-500 transition">
            Products
          </Link>

          {user?.role === 'admin' && (
            <Link to="/admin" className="text-gray-600 hover:text-orange-500 transition">
              Dashboard
            </Link>
          )}

          {user && (
            <Link to="/orders" className="text-gray-600 hover:text-orange-500 transition">
              Orders
            </Link>
          )}

          {/* Cart */}
          <Link to="/cart" className="relative">
            <span className="text-2xl">🛒</span>
            {totalItems > 0 && (
              <span className="absolute -top-1 -right-2 bg-orange-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold">
                {totalItems}
              </span>
            )}
          </Link>

          {user ? (
            <div className="flex items-center gap-2">
              <span className="text-gray-700 hidden sm:block">Hi, {user.name.split(' ')[0]}</span>
              <button onClick={handleLogout} className="btn-secondary text-sm py-1.5 px-3">
                Logout
              </button>
            </div>
          ) : (
            <div className="flex gap-2">
              <Link to="/login" className="btn-secondary text-sm py-1.5 px-3">Login</Link>
              <Link to="/register" className="btn-primary text-sm py-1.5 px-3">Register</Link>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
}
