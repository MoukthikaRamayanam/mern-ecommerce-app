import { useEffect, useState } from 'react';
import {
  fetchProducts,
  createProduct,
  updateProduct,
  deleteProduct,
  fetchAllOrders,
  updateOrderStatus,
} from '../services/api';
import { Loader } from '../components/shared';
import toast from 'react-hot-toast';

const EMPTY_FORM = {
  name: '', description: '', price: '', category: '', image: '', stock: '',
};

export default function Admin() {
  const [tab, setTab] = useState('products');
  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState(EMPTY_FORM);
  const [editId, setEditId] = useState(null);
  const [showForm, setShowForm] = useState(false);

  const loadAll = async () => {
    setLoading(true);
    const [p, o] = await Promise.all([fetchProducts(), fetchAllOrders()]);
    setProducts(p.data);
    setOrders(o.data);
    setLoading(false);
  };

  useEffect(() => { loadAll(); }, []);

  const handleFormChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const openEdit = (product) => {
    setForm({ ...product, price: product.price.toString(), stock: product.stock.toString() });
    setEditId(product._id);
    setShowForm(true);
  };

  const openNew = () => {
    setForm(EMPTY_FORM);
    setEditId(null);
    setShowForm(true);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    try {
      const payload = { ...form, price: parseFloat(form.price), stock: parseInt(form.stock) };
      if (editId) {
        await updateProduct(editId, payload);
        toast.success('Product updated');
      } else {
        await createProduct(payload);
        toast.success('Product created');
      }
      setShowForm(false);
      loadAll();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Save failed');
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this product?')) return;
    try {
      await deleteProduct(id);
      toast.success('Product deleted');
      loadAll();
    } catch {
      toast.error('Delete failed');
    }
  };

  const handleStatusChange = async (orderId, status) => {
    try {
      await updateOrderStatus(orderId, status);
      toast.success('Status updated');
      loadAll();
    } catch {
      toast.error('Failed to update status');
    }
  };

  if (loading) return <Loader />;

  return (
    <div className="max-w-7xl mx-auto px-4 py-10">
      <h1 className="font-display text-3xl font-bold mb-2">Admin Dashboard</h1>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
        {[
          { label: 'Products', value: products.length, icon: '📦' },
          { label: 'Orders', value: orders.length, icon: '🛒' },
          { label: 'Revenue', value: `$${orders.reduce((a, o) => a + o.totalPrice, 0).toFixed(0)}`, icon: '💰' },
          { label: 'Pending', value: orders.filter((o) => o.status === 'pending').length, icon: '⏳' },
        ].map((s) => (
          <div key={s.label} className="card p-4">
            <p className="text-2xl mb-1">{s.icon}</p>
            <p className="font-display text-2xl font-bold text-gray-900">{s.value}</p>
            <p className="text-sm text-gray-500">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-6">
        {['products', 'orders'].map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-5 py-2 rounded-xl font-medium capitalize transition ${
              tab === t ? 'bg-orange-500 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {/* Products Tab */}
      {tab === 'products' && (
        <>
          <div className="flex justify-between items-center mb-4">
            <h2 className="font-display text-xl font-bold">Products</h2>
            <button onClick={openNew} className="btn-primary">+ Add Product</button>
          </div>

          {/* Product Form Modal */}
          {showForm && (
            <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
              <div className="bg-white rounded-2xl p-6 w-full max-w-lg max-h-[90vh] overflow-y-auto">
                <h3 className="font-display text-xl font-bold mb-4">
                  {editId ? 'Edit Product' : 'New Product'}
                </h3>
                <form onSubmit={handleSave} className="space-y-3">
                  {[
                    { name: 'name', label: 'Name', type: 'text' },
                    { name: 'price', label: 'Price ($)', type: 'number' },
                    { name: 'category', label: 'Category', type: 'text' },
                    { name: 'stock', label: 'Stock', type: 'number' },
                    { name: 'image', label: 'Image URL', type: 'url' },
                  ].map(({ name, label, type }) => (
                    <div key={name}>
                      <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
                      <input
                        name={name}
                        type={type}
                        value={form[name]}
                        onChange={handleFormChange}
                        required
                        className="input"
                      />
                    </div>
                  ))}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                    <textarea
                      name="description"
                      value={form.description}
                      onChange={handleFormChange}
                      rows={3}
                      required
                      className="input resize-none"
                    />
                  </div>
                  <div className="flex gap-3 pt-2">
                    <button type="submit" className="btn-primary flex-1">
                      {editId ? 'Update' : 'Create'}
                    </button>
                    <button type="button" onClick={() => setShowForm(false)} className="btn-secondary flex-1">
                      Cancel
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          <div className="card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50 border-b border-gray-100">
                  <tr>
                    {['Product', 'Category', 'Price', 'Stock', 'Actions'].map((h) => (
                      <th key={h} className="text-left px-4 py-3 text-gray-600 font-medium">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {products.map((p) => (
                    <tr key={p._id} className="hover:bg-gray-50/50">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <img src={p.image} alt={p.name} className="w-10 h-10 rounded-lg object-cover" />
                          <span className="font-medium max-w-[180px] truncate">{p.name}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-gray-500">{p.category}</td>
                      <td className="px-4 py-3 font-semibold">${p.price.toFixed(2)}</td>
                      <td className="px-4 py-3">
                        <span className={`badge ${p.stock > 0 ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>
                          {p.stock}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex gap-2">
                          <button onClick={() => openEdit(p)} className="text-blue-500 hover:text-blue-700 text-xs font-medium">Edit</button>
                          <button onClick={() => handleDelete(p._id)} className="text-red-500 hover:text-red-700 text-xs font-medium">Delete</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}

      {/* Orders Tab */}
      {tab === 'orders' && (
        <>
          <h2 className="font-display text-xl font-bold mb-4">Orders</h2>
          <div className="card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50 border-b border-gray-100">
                  <tr>
                    {['Order ID', 'Customer', 'Total', 'Date', 'Status'].map((h) => (
                      <th key={h} className="text-left px-4 py-3 text-gray-600 font-medium">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {orders.map((o) => (
                    <tr key={o._id} className="hover:bg-gray-50/50">
                      <td className="px-4 py-3 font-mono text-xs text-gray-500">{o._id.slice(-8)}</td>
                      <td className="px-4 py-3">
                        <p className="font-medium">{o.user?.name || 'N/A'}</p>
                        <p className="text-xs text-gray-400">{o.user?.email}</p>
                      </td>
                      <td className="px-4 py-3 font-bold text-orange-500">${o.totalPrice.toFixed(2)}</td>
                      <td className="px-4 py-3 text-gray-500">
                        {new Date(o.createdAt).toLocaleDateString()}
                      </td>
                      <td className="px-4 py-3">
                        <select
                          value={o.status}
                          onChange={(e) => handleStatusChange(o._id, e.target.value)}
                          className="text-xs border border-gray-200 rounded-lg px-2 py-1 focus:outline-none focus:ring-1 focus:ring-orange-400"
                        >
                          {['pending', 'processing', 'shipped', 'delivered'].map((s) => (
                            <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>
                          ))}
                        </select>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
