import { useEffect, useState } from 'react';
import { fetchMyOrders } from '../services/api';
import { Loader } from '../components/shared';

const STATUS_COLORS = {
  pending: 'bg-yellow-50 text-yellow-700',
  processing: 'bg-blue-50 text-blue-700',
  shipped: 'bg-purple-50 text-purple-700',
  delivered: 'bg-green-50 text-green-700',
};

export default function Orders() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchMyOrders()
      .then(({ data }) => setOrders(data))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <Loader />;

  return (
    <div className="max-w-4xl mx-auto px-4 py-10">
      <h1 className="font-display text-3xl font-bold mb-8">My Orders</h1>

      {orders.length === 0 ? (
        <div className="text-center py-20 text-gray-400">
          <p className="text-5xl mb-3">📦</p>
          <p className="text-lg">No orders yet</p>
        </div>
      ) : (
        <div className="space-y-4">
          {orders.map((order) => (
            <div key={order._id} className="card p-6">
              <div className="flex flex-wrap gap-4 justify-between items-start mb-4">
                <div>
                  <p className="text-xs text-gray-400 mb-1">Order ID</p>
                  <p className="font-mono text-sm text-gray-700">{order._id}</p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-gray-400 mb-1">Date</p>
                  <p className="text-sm text-gray-700">
                    {new Date(order.createdAt).toLocaleDateString()}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-gray-400 mb-1">Total</p>
                  <p className="font-bold text-orange-500">${order.totalPrice.toFixed(2)}</p>
                </div>
                <span className={`badge ${STATUS_COLORS[order.status]} capitalize px-3 py-1`}>
                  {order.status}
                </span>
              </div>

              {/* Items */}
              <div className="border-t border-gray-100 pt-4 flex flex-wrap gap-3">
                {order.items.map((item, i) => (
                  <div key={i} className="flex items-center gap-2 bg-gray-50 rounded-lg p-2">
                    <img src={item.image} alt={item.name} className="w-10 h-10 rounded-lg object-cover" />
                    <div>
                      <p className="text-xs font-medium line-clamp-1 max-w-[120px]">{item.name}</p>
                      <p className="text-xs text-gray-500">×{item.qty}</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Shipping */}
              <p className="text-xs text-gray-400 mt-3">
                📍 {order.shippingAddress.address}, {order.shippingAddress.city},{' '}
                {order.shippingAddress.country}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
