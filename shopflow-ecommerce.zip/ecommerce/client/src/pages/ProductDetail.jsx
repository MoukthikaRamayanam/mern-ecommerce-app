import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { fetchProductById } from '../services/api';
import { useCart } from '../context/CartContext';
import { Loader } from '../components/shared';
import toast from 'react-hot-toast';

export default function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const [product, setProduct] = useState(null);
  const [qty, setQty] = useState(1);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProductById(id)
      .then(({ data }) => setProduct(data))
      .catch(() => navigate('/'))
      .finally(() => setLoading(false));
  }, [id, navigate]);

  if (loading) return <Loader />;
  if (!product) return null;

  const handleAdd = () => {
    addToCart(product, qty);
    toast.success(`${product.name} added to cart!`);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-10">
      <button onClick={() => navigate(-1)} className="text-orange-500 hover:underline text-sm mb-6 block">
        ← Back
      </button>

      <div className="card p-0 overflow-hidden grid md:grid-cols-2 gap-0">
        {/* Image */}
        <div className="bg-gray-50 h-80 md:h-auto">
          <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
        </div>

        {/* Info */}
        <div className="p-8 flex flex-col">
          <span className="badge bg-orange-50 text-orange-600 mb-2 w-fit">{product.category}</span>
          <h1 className="font-display text-3xl font-bold text-gray-900 mb-3">{product.name}</h1>
          <p className="text-gray-500 mb-6 leading-relaxed">{product.description}</p>

          <div className="flex items-center gap-3 mb-6">
            <span className="font-display text-3xl font-bold text-gray-900">
              ${product.price.toFixed(2)}
            </span>
            {product.stock > 0 ? (
              <span className="badge bg-green-50 text-green-700">{product.stock} in stock</span>
            ) : (
              <span className="badge bg-red-50 text-red-700">Out of stock</span>
            )}
          </div>

          {/* Qty selector */}
          {product.stock > 0 && (
            <div className="flex items-center gap-3 mb-6">
              <span className="text-sm font-medium text-gray-700">Quantity:</span>
              <div className="flex items-center border border-gray-200 rounded-lg overflow-hidden">
                <button
                  onClick={() => setQty((q) => Math.max(1, q - 1))}
                  className="px-3 py-2 hover:bg-gray-50 transition"
                >
                  −
                </button>
                <span className="px-4 py-2 font-medium border-x border-gray-200">{qty}</span>
                <button
                  onClick={() => setQty((q) => Math.min(product.stock, q + 1))}
                  className="px-3 py-2 hover:bg-gray-50 transition"
                >
                  +
                </button>
              </div>
            </div>
          )}

          <div className="flex gap-3 mt-auto">
            <button onClick={handleAdd} disabled={product.stock === 0} className="btn-primary flex-1 disabled:opacity-50">
              Add to Cart
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
