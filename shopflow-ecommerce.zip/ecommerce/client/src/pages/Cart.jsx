import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';

export default function Cart() {
  const { cart, removeFromCart, updateQty, totalPrice } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();

  if (cart.length === 0)
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center">
        <p className="text-6xl mb-4">🛒</p>
        <h2 className="font-display text-2xl font-bold mb-2">Your cart is empty</h2>
        <p className="text-gray-500 mb-6">Add some products to get started</p>
        <Link to="/" className="btn-primary inline-block">Browse Products</Link>
      </div>
    );

  return (
    <div className="max-w-5xl mx-auto px-4 py-10">
      <h1 className="font-display text-3xl font-bold mb-8">Shopping Cart</h1>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Items */}
        <div className="lg:col-span-2 space-y-4">
          {cart.map((item) => (
            <div key={item._id} className="card p-4 flex gap-4 items-center">
              <img
                src={item.image}
                alt={item.name}
                className="w-20 h-20 object-cover rounded-xl flex-shrink-0"
              />
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-gray-900 truncate">{item.name}</p>
                <p className="text-orange-500 font-bold">${item.price.toFixed(2)}</p>
              </div>
              <div className="flex items-center border border-gray-200 rounded-lg overflow-hidden flex-shrink-0">
                <button
                  onClick={() => updateQty(item._id, item.qty - 1)}
                  className="px-2.5 py-1.5 hover:bg-gray-50 text-lg"
                >
                  −
                </button>
                <span className="px-3 py-1.5 font-medium border-x border-gray-200">{item.qty}</span>
                <button
                  onClick={() => updateQty(item._id, item.qty + 1)}
                  className="px-2.5 py-1.5 hover:bg-gray-50 text-lg"
                >
                  +
                </button>
              </div>
              <p className="font-bold w-20 text-right flex-shrink-0">
                ${(item.price * item.qty).toFixed(2)}
              </p>
              <button
                onClick={() => removeFromCart(item._id)}
                className="text-red-400 hover:text-red-600 flex-shrink-0 transition"
              >
                ✕
              </button>
            </div>
          ))}
        </div>

        {/* Summary */}
        <div className="card p-6 h-fit">
          <h2 className="font-display text-xl font-bold mb-4">Order Summary</h2>
          <div className="space-y-2 mb-4 text-sm">
            {cart.map((i) => (
              <div key={i._id} className="flex justify-between text-gray-600">
                <span className="truncate max-w-[60%]">{i.name} × {i.qty}</span>
                <span>${(i.price * i.qty).toFixed(2)}</span>
              </div>
            ))}
          </div>
          <div className="border-t border-gray-100 pt-4 flex justify-between font-bold text-lg mb-6">
            <span>Total</span>
            <span className="text-orange-500">${totalPrice.toFixed(2)}</span>
          </div>
          <button
            onClick={() => user ? navigate('/checkout') : navigate('/login')}
            className="btn-primary w-full text-center"
          >
            {user ? 'Proceed to Checkout' : 'Login to Checkout'}
          </button>
        </div>
      </div>
    </div>
  );
}
