import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { createOrder } from '../services/api';
import toast from 'react-hot-toast';

export default function Checkout() {
  const { cart, totalPrice, clearCart } = useCart();
  const navigate = useNavigate();
  const [form, setForm] = useState({ address: '', city: '', postalCode: '', country: '' });
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!cart.length) return;
    setLoading(true);
    try {
      const items = cart.map((i) => ({
        product: i._id,
        name: i.name,
        image: i.image,
        price: i.price,
        qty: i.qty,
      }));
      await createOrder({ items, shippingAddress: form, totalPrice });
      clearCart();
      toast.success('Order placed successfully!');
      navigate('/orders');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Order failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-10">
      <h1 className="font-display text-3xl font-bold mb-8">Checkout</h1>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Shipping Form */}
        <div className="card p-6">
          <h2 className="font-display text-xl font-bold mb-6">Shipping Address</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            {[
              { name: 'address', label: 'Street Address', placeholder: '123 Main St' },
              { name: 'city', label: 'City', placeholder: 'New York' },
              { name: 'postalCode', label: 'Postal Code', placeholder: '10001' },
              { name: 'country', label: 'Country', placeholder: 'United States' },
            ].map(({ name, label, placeholder }) => (
              <div key={name}>
                <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
                <input
                  name={name}
                  value={form[name]}
                  onChange={handleChange}
                  placeholder={placeholder}
                  required
                  className="input"
                />
              </div>
            ))}

            <button type="submit" disabled={loading} className="btn-primary w-full mt-2 disabled:opacity-70">
              {loading ? 'Placing Order...' : 'Place Order'}
            </button>
          </form>
        </div>

        {/* Order Summary */}
        <div className="card p-6 h-fit">
          <h2 className="font-display text-xl font-bold mb-4">Order Items</h2>
          <div className="space-y-3 mb-4">
            {cart.map((item) => (
              <div key={item._id} className="flex gap-3 items-center">
                <img src={item.image} alt={item.name} className="w-12 h-12 rounded-lg object-cover flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{item.name}</p>
                  <p className="text-xs text-gray-500">Qty: {item.qty}</p>
                </div>
                <p className="font-semibold text-sm">${(item.price * item.qty).toFixed(2)}</p>
              </div>
            ))}
          </div>
          <div className="border-t border-gray-100 pt-4 flex justify-between font-bold text-lg">
            <span>Total</span>
            <span className="text-orange-500">${totalPrice.toFixed(2)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
