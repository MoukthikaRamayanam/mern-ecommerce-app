# 🛒 ShopFlow — Full-Stack E-Commerce App

A production-ready MERN stack e-commerce application with JWT auth, admin dashboard, and full shopping flow.

## Tech Stack
- **Frontend**: React.js, Tailwind CSS, React Router
- **Backend**: Node.js, Express.js
- **Database**: MongoDB + Mongoose
- **Auth**: JWT (JSON Web Tokens)

## Features
- User Register / Login
- Product Listing & Details
- Add to Cart / Checkout
- Order History
- Admin Dashboard (Add / Edit / Delete Products)
- Role-based Auth (Admin / User)

## Project Structure
```
ecommerce/
├── client/          # React frontend
│   └── src/
│       ├── pages/
│       ├── components/
│       ├── context/
│       └── services/
└── server/          # Express backend
    ├── controllers/
    ├── middleware/
    ├── models/
    └── routes/
```

## Quick Start

### 1. Clone & Install
```bash
# Install server deps
cd server && npm install

# Install client deps
cd ../client && npm install
```

### 2. Environment Setup
```bash
# server/.env
cp server/.env.example server/.env
# Fill in your MongoDB URI and JWT Secret
```

### 3. Run the App
```bash
# Terminal 1 — Backend
cd server && npm run dev

# Terminal 2 — Frontend
cd client && npm start
```

### 4. Seed Admin User
POST to `/api/auth/register` with:
```json
{ "name": "Admin", "email": "admin@shop.com", "password": "admin123", "role": "admin" }
```

## API Endpoints
| Method | Route | Access |
|--------|-------|--------|
| POST | /api/auth/register | Public |
| POST | /api/auth/login | Public |
| GET | /api/products | Public |
| GET | /api/products/:id | Public |
| POST | /api/products | Admin |
| PUT | /api/products/:id | Admin |
| DELETE | /api/products/:id | Admin |
| POST | /api/orders | Auth |
| GET | /api/orders/myorders | Auth |
| GET | /api/orders | Admin |

## Deploy
- **Backend**: Railway, Render, or Heroku
- **Frontend**: Vercel or Netlify
- **Database**: MongoDB Atlas

## License
MIT
